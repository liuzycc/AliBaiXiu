// 初始化( initialize )
define( function () {

    console.log( '这里是一个初始化的模块, 应该第一个执行' );

} );