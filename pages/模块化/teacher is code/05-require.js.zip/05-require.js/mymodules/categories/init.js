// 定义 初始化 模块
// 需要使用 工具
define( [ 'tools' ], function ( abc ) {

    console.log( abc );

} );