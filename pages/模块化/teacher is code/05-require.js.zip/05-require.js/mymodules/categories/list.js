// list 需要加载页面的数据
define( [ 'catinit' ], function () {

    console.log( '加载页面数据' );
    
} );